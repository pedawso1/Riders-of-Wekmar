/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package application;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 *
 * @author Kyle
 */
public class myCanvas {

    public Canvas newCanvas(int rows, int columns) {
        Canvas canvas = new Canvas(50 * columns, 50 * rows);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, 50 * columns, 50 * rows);
        drawGrid(gc, columns, rows);
        return canvas;
    }

    //Draw grid on canvas
    private void drawGrid(GraphicsContext gc, int columns, int rows) {
        for (int i = 0; i <= columns; i++) {
            gc.strokeLine(50 * i, 0, 50 * i, 50 * rows);
        }
        for (int i = 0; i <= rows; i++) {
            gc.strokeLine(0, 50 * i, 50 * columns, 50 * i);
        }
    }
}
