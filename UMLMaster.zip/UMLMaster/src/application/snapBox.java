package application;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.shape.Rectangle;

public class snapBox {

    // Box and global declarations for snap events
    Rectangle box;
    double firstHoldX, firstHoldY;
    double moveHoldX, moveHoldY;
    double moveX, moveY;
    int rows, columns;

    public Rectangle newBox(int x, int y) {
        box = new Rectangle();
        box.setX(0);
        box.setY(0);
        box.setWidth(100);
        box.setHeight(150);
        rows = x;
        columns = y;
        // press selects and gets current location
        box.setOnMousePressed(mousePressed);
        // drag determines distance to move and translation variables
        box.setOnMouseDragged(mouseDragged);
        // modifies location to align on grid spaces
        box.setOnMouseReleased(mouseReleased);
        return box;
    }

    // Gets location and gives to drag
    EventHandler<MouseEvent> mousePressed = new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent t) {
            firstHoldX = t.getSceneX();
            firstHoldY = t.getSceneY();
            moveHoldX = box.getTranslateX();
            moveHoldY = box.getTranslateY();
        }
    };
    // determines new location
    EventHandler<MouseEvent> mouseDragged = new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent t) {
            double changeX = t.getSceneX() - firstHoldX;
            double changeY = t.getSceneY() - firstHoldY;
            moveX = moveHoldX + changeX;
            moveY = moveHoldY + changeY;

            box.setTranslateX(moveX);
            box.setTranslateY(moveY);
        }
    };
    // changes new location to snap to grid
    EventHandler<MouseEvent> mouseReleased = new EventHandler<MouseEvent>() {
        public void handle(MouseEvent t) {
            if (moveX > 50 * rows || moveX < 0 || moveY > 50 * columns || moveY < 0) {
                box.setTranslateX(moveHoldX);
                box.setTranslateY(moveHoldY);
            } else {
                double firstX = t.getSceneX();
                double firstY = t.getSceneY();
                firstX = (firstX - firstX % 50);
                firstY = (firstY - firstY % 50);
                box.setTranslateX(firstX - 100);
                box.setTranslateY(firstY - 50);
            }
        }
    };

}
