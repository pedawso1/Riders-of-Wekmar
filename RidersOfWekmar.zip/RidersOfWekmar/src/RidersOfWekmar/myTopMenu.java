package RidersOfWekmar;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//myTopMenu is an object to add file options through drop down menus
public class myTopMenu {

	MenuBar menuBar = new MenuBar();
	ArrayList<Node> nodes = new ArrayList<Node>();
	TextBoxClass textBox;
	LineDrawer lineDrawer;
	label label;
	String addingToFile = "";
    mySidePanel sidePanel;

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public MenuBar addMenuBar(Stage primary, mySidePanel sp) {
                sidePanel = sp;
                Pane centerPane = sidePanel.getCenterPane();
		Menu menuFile = new javafx.scene.control.Menu("File");
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		MenuItem newFile = new MenuItem("New");
		
		//creates a new stage/window to make a new file 
				newFile.setOnAction((ActionEvent event) -> {
					Stage secondStage = new Stage();
					BorderPane border = new BorderPane();
					Pane centerPane2 = new Pane();
					centerPane2.getStyleClass().add("centerPane");
					mySidePanel sidePanel2 = new mySidePanel(centerPane2);
					myTopMenu bar = new myTopMenu();

					// layout of editor
					border.setLeft(sidePanel2.addSidePanel());
		            border.setTop(bar.addMenuBar(secondStage, sidePanel2));
					border.setCenter(centerPane2);

					Scene secondScene = new Scene(border, 800, 800);
					secondStage.setTitle("Riders of Wekmar Editor");
					secondStage.setScene(secondScene);
					secondScene.getStylesheets().add(RidersOfWekmar.class.getResource("application.css").toExternalForm());

					secondStage.show();
				});
		
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				
		MenuItem open = new MenuItem("Open");
		
		open.setOnAction(new EventHandler<ActionEvent>() {
			@Override
            public void handle(ActionEvent arg0) {
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Open Text");
                
                //Set extension filter
                FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
                fileChooser.getExtensionFilters().add(extFilter);
                 
                //Show save file dialog
                File file = fileChooser.showOpenDialog(primary);
                if(file != null){
                    try {
                    	Stage secondStage = new Stage();
    					BorderPane border = new BorderPane();
    					Pane centerPane2 = new Pane();
    					centerPane2.getStyleClass().add("centerPane");
    					mySidePanel sidePanel2 = new mySidePanel(centerPane2);
    					myTopMenu bar = new myTopMenu();

    					// layout of editor
    					border.setLeft(sidePanel2.addSidePanel());
    		            border.setTop(bar.addMenuBar(secondStage, sidePanel2));
    					border.setCenter(centerPane2);

    					Scene secondScene = new Scene(border, 800, 800);
    					
    					secondStage.setScene(secondScene);
    					secondScene.getStylesheets().add(RidersOfWekmar.class.getResource("application.css").toExternalForm());

    					secondStage.show();
    					LineDrawer lineDrawer = new LineDrawer(sidePanel2);
    					TextBoxClass textBox = new TextBoxClass(sidePanel2);
    					label label = new label(sidePanel2);
						readFile(file, lineDrawer, textBox, centerPane2, label);
						String name = file.getName();
						String newName = name.replaceAll(".txt", "");
						secondStage.setTitle(newName);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                }
            }
		});
		
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		MenuItem save = new MenuItem("Save");

		//saves in a text file
		save.setOnAction(new EventHandler<ActionEvent>() {
			// We have a functional save aspect that will store node type and location to a
			// text file, load function is planned but not functional
			public void handle(ActionEvent t) {
				FileChooser fc = new FileChooser();
				fc.setTitle("Save Text");
				nodes = getAllNodes(centerPane);
				int count = 0;
				for (int i = 0; i < nodes.size(); i++) {
					ArrayList<Double> list = new ArrayList<Double>();
					list = getBounds(nodes.get(i));
					//System.out.println(nodes.get(i).getId() + "%" + list);
					//System.out.println(nodes.get(i));
					//addingToFile = addingToFile + (nodes.get(i)).toString() + "\n";
					
					if (nodes.get(i).getId() == "Text Box") {
						addingToFile = addingToFile + (nodes.get(i).getId() + "%" + list).toString() + "\n";
						count = 0;
					}
					else if (nodes.get(i).getId() == "Text" && count < 3) {
						addingToFile = addingToFile + (nodes.get(i).getId() + "%" + nodes.get(i)).toString() + "\n";
						count = count + 1;
					}
					else if (nodes.get(i).getId() == "Label") {
						addingToFile = addingToFile + (nodes.get(i).getId() + "%" + list).toString() + "\n";
						count = 0;
					}
					
				}

				FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
				fc.getExtensionFilters().add(extFilter);
				File file = fc.showSaveDialog(primary);

				if (file != null) {
					SaveFile(addingToFile, file);
				}
				String name = file.getName();
				String newName = name.replaceAll(".txt", "");
				primary.setTitle(newName);
				addingToFile = "";
			}
		});

		// exiting the program
		MenuItem exit = new MenuItem("Exit", null);
		exit.setOnAction(actionEvent -> Platform.exit());

		// what is in the file tab
		menuFile.getItems().addAll(newFile, open, save, exit);

		// edit should contain the undos, redos and clear
		Menu menuEdit = new javafx.scene.control.Menu("Edit");
                MenuItem undo = new MenuItem("Undo");
                undo.setOnAction((ActionEvent e) -> 
                {
                    sidePanel.fireUndoBtn();
                });
                
                MenuItem redo = new MenuItem("Redo");
                redo.setOnAction((ActionEvent e) -> 
                {
                    sidePanel.fireRedoBtn();
                });
                
                
                menuEdit.getItems().addAll(undo, redo);

		// gives an information about the program
		Menu menuHelp = new javafx.scene.control.Menu("About");
		MenuItem about = new MenuItem("Welcome");
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("About");
		alert.setHeaderText("About The Riders Of Wekmar Editor");
		String s = "This program is created to produce uml diagrams. There are resizale textboxes with three sections"
				+ " name the class, instance variables and attributes. User has a choice of different lines to pick from to connect textboxes."
				+ "\n\n"
				+ "The main purpose to create the program was for a Software Engineering course by Ashley Camacho, Kailash Sayal, Kyle Marten, Peter Dawson and Samuel Aungst."
				+ "The Students attend Millersville University.";
		alert.setContentText(s);
		about.setOnAction(actionEvent -> alert.show());
		menuHelp.getItems().addAll(about);

		menuBar.getMenus().addAll(menuFile, menuEdit, /* menuView, */ menuHelp);

		return menuBar;

	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	private void SaveFile(String content, File file) {
		try {
			FileWriter fileWriter = null;

			fileWriter = new FileWriter(file);
			fileWriter.write(content);
			fileWriter.close();
		} catch (IOException ex) {
			Logger.getLogger(myTopMenu.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Fuction to return Arraylist of only top left corner of nodes
	// intended use is for snapping Lines to text boxes within a predetermined
	// proximity, currently not used
	public static ArrayList<Double> getMinBounds(Node node) {
		Bounds bounds;
		ArrayList<Double> list = new ArrayList<Double>();
		bounds = node.localToParent(node.getBoundsInLocal());
		list.add(bounds.getMinX());
		list.add(bounds.getMinY());
		return list;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Returns the bounds for all nodes in scene, returning both the min
	// and max X and Y coordinates too record both sides of lines and
	// also because we can resize our text boxes we need the diagonal coordinates
	// to determine location and size for save
	public static ArrayList<Double> getBounds(Node node) {
		Bounds bounds;
		ArrayList<Double> list = new ArrayList<Double>();
		bounds = node.localToParent(node.getBoundsInLocal());
		list.add(bounds.getMinX());
		list.add(bounds.getMinY());
		list.add(bounds.getMaxX());
		list.add(bounds.getMaxY());
		return list;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Returns all nodes from "root" and descendents
	public static ArrayList<Node> getAllNodes(Parent root) {
		ArrayList<Node> nodes = new ArrayList<Node>();
		addAllLabels(root, nodes);
		addAllTextBoxes(root, nodes);
		//addAllDescendents(root, nodes);
		return nodes;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Returns all descendents from parent node
	private static void addAllDescendents(Parent parent, ArrayList<Node> nodes) {
		for (Node node : parent.getChildrenUnmodifiable()) {
			nodes.add(node);
			if (node instanceof Parent)
				addAllDescendents((Parent)node, nodes);
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Returns all descendents from parent node
	private static void addAllLabels(Parent parent, ArrayList<Node> nodes) {
		for (Node node : parent.getChildrenUnmodifiable()) {
			if (node.getId() == "Label") {
				nodes.add(node);
				if (node.getId() == "Text") {
					node.setId("");
				}
			}
			if (node instanceof Parent) {
				addAllDescendents((Parent) node, nodes);
			}
		}
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Returns all TextBoxes and Text from parent node
	private static void addAllTextBoxes(Parent parent, ArrayList<Node> nodes) {
		for (Node node : parent.getChildrenUnmodifiable()) {
			if (node instanceof Pane) {
				nodes.add(node);
			}
			if (node instanceof Text) {
				node.setId("Text");
				nodes.add(node);
			}
			if (node instanceof Parent) {
				addAllTextBoxes((Parent) node, nodes);
			}
		}
	}
	
	
	
	
	private static void readFile(File file, LineDrawer lineDrawer, TextBoxClass textBox, Pane centerPane2, label label) throws IOException {
		FileReader in = new FileReader(file);
		BufferedReader br = new BufferedReader(in);
		String line;
		while ((line = br.readLine()) != null) {
			String[] parts = line.split("%");
			String fix1 = parts[1].replace("[", "");
			String fix2 = fix1.replace("]", "");
			String[] coords = fix2.split(", ");
			if (parts[0].equals("Line")) {
				double x1 = Double.parseDouble(coords[0]);
				double y1 = Double.parseDouble(coords[1]);
				double x2 = Double.parseDouble(coords[2]);
				double y2 = Double.parseDouble(coords[3]);
				lineDrawer.drawLine(x1, y1, x2, y2);
			}
			else if (parts[0].equals("Text Box")) {
				String special = "\"";
				double x1 = Double.parseDouble(coords[0]);
				double y1 = Double.parseDouble(coords[1]);
				String line2 = br.readLine();
				String[] cut1 = line2.split("%");
				String[] cut2 = cut1[1].split(special, 2);	
				int index = cut2[1].lastIndexOf("\", x=0.0, y=0.0, alignment=LEFT,");
				String className = cut2[1].substring(0, index);
				String line3 = br.readLine();
				String[] cut3 = line3.split("%");
				String[] cut4 = cut3[1].split(special, 2);
				int index2 = cut4[1].lastIndexOf("\", x=0.0, y=0.0, alignment=LEFT,");
				String vars = cut4[1].substring(0, index2);
				String line4 = br.readLine();
				String[] cut5 = line4.split("%");
				String[] cut6 = cut5[1].split(special, 2);
				int index3 = cut6[1].lastIndexOf("\", x=0.0, y=0.0, alignment=LEFT,");
				String attrs = cut6[1].substring(0, index3);
				textBox.spawn(centerPane2, x1, y1, className, vars, attrs);
			}
			else if (parts[0].equals("Label")) {
				String special = "\"";
				double x1 = Double.parseDouble(coords[0]);
				//System.out.println(x1);
				double y1 = Double.parseDouble(coords[1]);
				//System.out.println(y1);
				String line2 = br.readLine();
				String[] cut1 = line2.split("%");
				String[] cut2 = cut1[1].split(special, 2);	
				int index = cut2[1].lastIndexOf("\", x=0.0, y=0.0, alignment=LEFT,");
				String labelText = cut2[1].substring(0, index);
				int index2 = cut2[1].lastIndexOf("], fontSmoothing");
				int index3 = cut2[1].lastIndexOf("Bold, size=");
				String toCut = cut2[1].substring(index3, index2);
				String[] cut = toCut.split("=");
				String fontInt = cut[1];
				label.spawn(centerPane2, x1, y1, labelText, fontInt);
				
			}
			else if (parts[0].equals("Text")) {
				;
			}
		    //System.out.println(line);
		}
		in.close();
	}
}
